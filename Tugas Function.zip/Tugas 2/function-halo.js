function shoutOut() {
  return "Halo Function!"
}
console.log(shoutOut()); // Menampilkan "Halo Function!" di console

